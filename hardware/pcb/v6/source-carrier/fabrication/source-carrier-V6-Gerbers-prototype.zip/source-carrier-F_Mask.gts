%TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*%
%TF.CreationDate,2026-10-04T13:48:43+08:00*%
%TF.ProjectId,source-carrier,736f7572-6365-42d6-9361-72726965722e,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-10-04 13:48:43*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.800000*%
%ADD11RoundRect,0.150000X-0.150000X-0.625000X0.150000X-0.625000X0.150000X0.625000X-0.150000X0.625000X0*%
%ADD12RoundRect,0.250000X-0.350000X-0.650000X0.350000X-0.650000X0.350000X0.650000X-0.350000X0.650000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,L2*%
X26000000Y-7000000D03*
X26000000Y-10000000D03*
%TD*%
%TO.C,L3*%
X2000000Y-17000000D03*
X2000000Y-20000000D03*
%TD*%
D11*
%TO.C,J1*%
X11500000Y-26325000D03*
X12500000Y-26325000D03*
X13500000Y-26325000D03*
X14500000Y-26325000D03*
X15500000Y-26325000D03*
X16500000Y-26325000D03*
D12*
X10200000Y-23800000D03*
X17800000Y-23800000D03*
%TD*%
D10*
%TO.C,L1*%
X2000000Y-7000000D03*
X2000000Y-10000000D03*
%TD*%
M02*
